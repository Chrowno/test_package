
def amazing_function():
    print("Hello World")

if __name__ == "__main__":
    amazing_function()
